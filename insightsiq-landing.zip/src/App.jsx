import React from "react";
import { MotionConfig, motion } from "framer-motion";
import { Activity, Bolt, Brain, Cable, Database, Gauge, LineChart, Link2, ShieldCheck, Signal, Wrench, Zap } from "lucide-react";

const nav = [
  { label: "Solutions", href: "#solutions" },
  { label: "Products", href: "#products" },
  { label: "Onboarding", href: "#onboarding" },
  { label: "Learn", href: "#learn" },
  { label: "Company", href: "#company" },
];

const features = [
  { icon: <Gauge className="h-6 w-6" aria-hidden />, title: "Availability", desc: "Operate at true network availability — measured by successful sessions, not just online pings." },
  { icon: <Database className="h-6 w-6" aria-hidden />, title: "Data", desc: "Unify OCPP + OCPI + SIM telemetry. Stream, store, and compare error signatures at scale." },
  { icon: <Brain className="h-6 w-6" aria-hidden />, title: "AI", desc: "Spot drift, predict failures, and surface root causes before revenue is impacted." },
];

const challenges = [
  { title: "A bigger network means more data", desc: "Each charger emits thousands of events daily. Humans shouldn’t sift OCPP logs line-by-line." },
  { title: "Reactive instead of proactive", desc: "Outages shouldn’t surprise you. Predict risk windows days in advance and auto-remediate." },
  { title: "Customers know before you do", desc: "Online ≠ usable. Optimize toward completed sessions and payment success, not just uptime." },
  { title: "Error codes aren’t enough", desc: "Cross-correlate faults, weather, grid, SIM, and asset history to find the real cause." },
];

const steps = [
  { k: "Analytics & Evaluation", title: "Make your data comparable and prioritized", desc: "Normalize events, cluster issues, and rank the biggest levers for availability and margin.", stat: "-35%", statHint: "MTTR vs. baseline*", icon: <LineChart className="h-5 w-5" aria-hidden /> },
  { k: "Predict", title: "Know failures days ahead", desc: "Model micro-patterns in current, voltage, connector latch cycles, and SIM flapping.", stat: "+18%", statHint: "prevented truck rolls*", icon: <Activity className="h-5 w-5" aria-hidden /> },
  { k: "Automate", title: "Let software do the busywork", desc: "Policy-driven restarts, dynamic derates, and ticket deduping with human-in-the-loop control.", stat: "52%", statHint: "of incidents self-healed*", icon: <Zap className="h-5 w-5" aria-hidden /> },
  { k: "Collaborate", title: "Work the big cases together", desc: "Shared issue rooms with OEM, CPMS, and field ops. Close loops with evidence.", stat: "1 place", statHint: "for OEM ↔ CPO ops", icon: <Link2 className="h-5 w-5" aria-hidden /> },
];

const products = [
  { name: "Monitor", badge: "Start", desc: "Get value fast from OCPI/CPMS data — health scoring, session success KPIs, and anomaly hints.", bullets: ["Plug-and-play OCPI", "Fleet & site scorecards", "Incident clustering"], icon: <Signal className="h-6 w-6" aria-hidden /> },
  { name: "Predict", badge: "Pro", desc: "OCPP-driven predictive maintenance with component-level risk and lead-time forecasts.", bullets: ["Connector risk index", "Pre-failure alerts", "Parts & labor planner"], icon: <Bolt className="h-6 w-6" aria-hidden /> },
  { name: "Automate", badge: "Ops AI", desc: "Self-heal playbooks — safe restarts, SIM resync, cache clears, and CPMS ticket actions.", bullets: ["Policy engine", "Change audits", "Ops runbooks"], icon: <Wrench className="h-6 w-6" aria-hidden /> },
  { name: "Bridge API", badge: "Platform", desc: "Expose InsightsIQ models and signals via API so CPMS and OEM partners can embed them.", bullets: ["REST/GraphQL", "Webhooks", "Fine-grained scopes"], icon: <Cable className="h-6 w-6" aria-hidden /> },
];

const integrations = ["OCPP 1.6/2.0.1", "OCPI 2.2.1", "Monta", "Virta", "ChargePoint*", "Hubject*", "Flexecharge*", "SIM/ICCID"];

export default function App() {
  return (
    <MotionConfig reducedMotion="user">
      <div className="min-h-screen w-full bg-gradient-to-b from-slate-50 via-white to-slate-50 text-slate-900">
        {/* Header */}
        <header className="sticky top-0 z-40 backdrop-blur supports-[backdrop-filter]:bg-white/70 bg-white/60 border-b border-slate-200">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="flex h-16 items-center justify-between">
              <a href="#" className="flex items-center gap-2 font-semibold">
                <span className="inline-flex h-8 w-8 items-center justify-center rounded-xl bg-slate-900 text-white">IQ</span>
                <span className="text-slate-900">InsightsIQ</span>
              </a>
              <nav className="hidden md:flex items-center gap-6 text-sm">
                {nav.map((n) => (
                  <a key={n.label} href={n.href} className="hover:text-slate-600">{n.label}</a>
                ))}
              </nav>
              <div className="flex items-center gap-3">
                <a href="#contact" className="hidden sm:inline-block rounded-xl border border-slate-300 px-4 py-2 text-sm hover:bg-slate-100">Book a demo</a>
                <a href="#contact" className="inline-block rounded-xl bg-slate-900 px-4 py-2 text-sm text-white hover:bg-slate-800">Get started</a>
              </div>
            </div>
          </div>
        </header>

        {/* Hero */}
        <section className="relative overflow-hidden">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-20 sm:py-28">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <motion.h1 initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} className="text-3xl sm:text-5xl font-bold leading-tight">
                  Make EV‑charging availability the default
                </motion.h1>
                <p className="mt-5 text-slate-600 text-lg max-w-xl">
                  InsightsIQ is the AI operations platform for CPOs, CPMS, and charger OEMs. Monitor, predict, and automate — from signal to solved.
                </p>
                <div className="mt-8 flex flex-wrap gap-3">
                  <a href="#products" className="rounded-xl bg-slate-900 px-5 py-3 text-sm text-white hover:bg-slate-800">Explore products</a>
                  <a href="#learn" className="rounded-xl border border-slate-300 px-5 py-3 text-sm hover:bg-slate-100">See how it works</a>
                </div>
                <div className="mt-8 grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
                  {[
                    { k: "99.2%", t: "target real availability" },
                    { k: "7d", t: "pre-failure horizon" },
                    { k: "52%", t: "incidents self-healed" },
                    { k: "-35%", t: "MTTR reduction" },
                  ].map((s) => (
                    <div key={s.t} className="rounded-2xl border border-slate-200 p-4">
                      <div className="text-2xl font-semibold">{s.k}</div>
                      <div className="text-[13px] text-slate-500">{s.t}</div>
                    </div>
                  ))}
                </div>
              </div>
              <div className="relative">
                <motion.div initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.6 }} className="rounded-3xl border border-slate-200 bg-white p-4 shadow-xl">
                  <div className="rounded-2xl bg-slate-50 p-6">
                    <div className="mb-4 flex items-center gap-2 text-sm text-slate-500"><ShieldCheck className="h-4 w-4"/> AI Ops Console — Demo</div>
                    <div className="grid grid-cols-2 gap-4">
                      {[
                        { title: "Issue Radar", sub: "Clustered faults, ranked by revenue impact" },
                        { title: "Prediction", sub: "Connector risk and lead-time" },
                        { title: "Automation", sub: "Safe restart + SIM resync" },
                        { title: "Deep Insight", sub: "Compare OCPP traces by outcome" },
                      ].map((c) => (
                        <div key={c.title} className="rounded-xl p-4 bg-white border border-slate-200">
                          <div className="text-sm font-medium">{c.title}</div>
                          <div className="mt-2 text-xs text-slate-500">{c.sub}</div>
                          <div className="mt-3 h-16 rounded-lg bg-slate-100"></div>
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              </div>
            </div>
          </div>
        </section>

        {/* Integrations */}
        <section className="py-6 border-y border-slate-200 bg-white">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="flex flex-wrap items-center justify-center gap-x-10 gap-y-4 text-sm text-slate-600">
              {integrations.map((i) => (
                <div key={i} className="flex items-center gap-2"><Signal className="h-4 w-4"/>{i}</div>
              ))}
            </div>
          </div>
        </section>

        {/* Solutions */}
        <section id="solutions" className="py-20">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <h2 className="text-2xl sm:text-3xl font-bold">The business case only knows real availability</h2>
            <p className="mt-3 max-w-3xl text-slate-600">Track what matters: completed sessions, power delivered, and revenue retention. InsightsIQ aligns KPIs to outcomes, not just uptime.</p>

            <div className="mt-10 grid md:grid-cols-3 gap-6">
              {features.map((f) => (
                <div key={f.title} className="rounded-2xl border border-slate-200 p-6 bg-white shadow-sm">
                  <div className="mb-3 text-slate-900">{f.icon}</div>
                  <div className="font-semibold">{f.title}</div>
                  <p className="mt-2 text-sm text-slate-600">{f.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Challenges */}
        <section className="py-16 bg-slate-50 border-y border-slate-200">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <h3 className="text-xl sm:text-2xl font-semibold">The most common challenges</h3>
            <div className="mt-8 grid md:grid-cols-2 gap-6">
              {challenges.map((c) => (
                <div key={c.title} className="rounded-2xl bg-white border border-slate-200 p-6">
                  <div className="font-medium">{c.title}</div>
                  <p className="mt-2 text-sm text-slate-600">{c.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Learn */}
        <section id="learn" className="py-20">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <h3 className="text-xl sm:text-2xl font-semibold">InsightsIQ in 4 steps</h3>
            <p className="mt-2 text-slate-600 max-w-3xl">Availability at the center of a profitable CPO business. From analytics to automation, built for real-world ops.</p>

            <div className="mt-10 grid lg:grid-cols-4 gap-6">
              {steps.map((s) => (
                <div key={s.k} className="rounded-2xl border border-slate-200 bg-white p-6">
                  <div className="flex items-center gap-2 text-xs text-slate-500 uppercase tracking-wide"><span className="inline-flex items-center justify-center rounded-lg bg-slate-100 p-2 text-slate-700">{s.icon}</span>{s.k}</div>
                  <div className="mt-3 font-semibold">{s.title}</div>
                  <p className="mt-2 text-sm text-slate-600">{s.desc}</p>
                  <div className="mt-4 flex items-baseline gap-2">
                    <div className="text-2xl font-semibold">{s.stat}</div>
                    <div className="text-xs text-slate-500">{s.statHint}</div>
                  </div>
                </div>
              ))}
            </div>
            <p className="mt-4 text-xs text-slate-500">*Illustrative. Replace with your measured benchmarks.</p>
          </div>
        </section>

        {/* Products */}
        <section id="products" className="py-20 bg-slate-50 border-y border-slate-200">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <h3 className="text-xl sm:text-2xl font-semibold">Products</h3>
            <div className="mt-8 grid md:grid-cols-2 xl:grid-cols-4 gap-6">
              {products.map((p) => (
                <div key={p.name} className="rounded-2xl bg-white border border-slate-200 p-6 shadow-sm">
                  <div className="flex items-center justify-between">
                    <div className="font-semibold">{p.name}</div>
                    <span className="text-xs rounded-md bg-slate-900 text-white px-2 py-1">{p.badge}</span>
                  </div>
                  <p className="mt-2 text-sm text-slate-600">{p.desc}</p>
                  <ul className="mt-3 space-y-2 text-sm text-slate-700">
                    {p.bullets.map((b) => (
                      <li key={b} className="flex items-center gap-2"><Bolt className="h-4 w-4"/>{b}</li>
                    ))}
                  </ul>
                  <div className="mt-4 inline-flex items-center gap-2 text-sm font-medium text-slate-900">
                    {p.icon}
                    <span>Learn more</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Onboarding */}
        <section id="onboarding" className="py-20">
          <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
            <div className="rounded-3xl border border-slate-200 bg-white p-8 sm:p-12 text-center shadow-sm">
              <h3 className="text-2xl font-semibold">Get started</h3>
              <p className="mt-2 text-slate-600">Run a 14‑day pilot: connect sites, baseline availability, and validate predictions against reality.</p>
              <div className="mt-6 flex flex-wrap justify-center gap-3">
                <a href="#contact" className="rounded-xl bg-slate-900 px-5 py-3 text-sm text-white hover:bg-slate-800">Book a demo</a>
                <a href="#contact" className="rounded-xl border border-slate-300 px-5 py-3 text-sm hover:bg-slate-100">Contact sales</a>
              </div>
            </div>
          </div>
        </section>

        {/* Contact */}
        <section id="contact" className="py-20 bg-slate-50 border-y border-slate-200">
          <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
            <div className="grid md:grid-cols-2 gap-8 items-start">
              <div className="rounded-2xl bg-white border border-slate-200 p-6">
                <h4 className="text-lg font-semibold">Talk to us</h4>
                <p className="mt-2 text-sm text-slate-600">Tell us about your network size, charger mix, and existing CPMS. We’ll tailor a plan.</p>

                {/* Option 1: Formspree (replace YOUR_ENDPOINT below) */}
                {/* Option 2: Netlify Forms - add data-netlify="true" and hidden input */}
                <form className="mt-4 space-y-3" action="https://formspree.io/f/YOUR_ENDPOINT" method="POST">
                  <input required name="name" placeholder="Name" className="w-full rounded-xl border border-slate-300 px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-slate-900/20"/>
                  <input required name="email" type="email" placeholder="Work email" className="w-full rounded-xl border border-slate-300 px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-slate-900/20"/>
                  <input name="company" placeholder="Company" className="w-full rounded-xl border border-slate-300 px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-slate-900/20"/>
                  <textarea name="message" placeholder="What would you like to improve?" className="w-full rounded-xl border border-slate-300 px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-slate-900/20" rows={4}/>
                  <button className="w-full rounded-xl bg-slate-900 px-5 py-3 text-sm text-white hover:bg-slate-800">Send</button>
                  <p className="text-[11px] text-slate-500">By submitting, you agree to our privacy policy.</p>
                </form>

                {/* Netlify fallback example (comment out the Formspree form and uncomment this one if you use Netlify)
                <form className="mt-4 space-y-3" name="contact" method="POST" data-netlify="true">
                  <input type="hidden" name="form-name" value="contact" />
                  <input required name="name" placeholder="Name" className="w-full rounded-xl border border-slate-300 px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-slate-900/20"/>
                  <input required name="email" type="email" placeholder="Work email" className="w-full rounded-xl border border-slate-300 px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-slate-900/20"/>
                  <input name="company" placeholder="Company" className="w-full rounded-xl border border-slate-300 px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-slate-900/20"/>
                  <textarea name="message" placeholder="What would you like to improve?" className="w-full rounded-xl border border-slate-300 px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-slate-900/20" rows={4}/>
                  <button className="w-full rounded-xl bg-slate-900 px-5 py-3 text-sm text-white hover:bg-slate-800">Send</button>
                  <p className="text-[11px] text-slate-500">By submitting, you agree to our privacy policy.</p>
                </form>*/}
              </div>
              <div className="rounded-2xl bg-white border border-slate-200 p-6">
                <h4 className="text-lg font-semibold">Why InsightsIQ</h4>
                <ul className="mt-3 space-y-3 text-sm text-slate-700">
                  <li className="flex items-start gap-2"><ShieldCheck className="h-4 w-4 mt-1"/> Designed for CPOs, CPMS, and OEMs working with OCPP/OCPI at scale.</li>
                  <li className="flex items-start gap-2"><ShieldCheck className="h-4 w-4 mt-1"/> Predictive maintenance focused on session success and revenue — not just device ping.</li>
                  <li className="flex items-start gap-2"><ShieldCheck className="h-4 w-4 mt-1"/> APIs to embed predictions and actions in your existing tools.</li>
                  <li className="flex items-start gap-2"><ShieldCheck className="h-4 w-4 mt-1"/> Privacy-first. Region-pinned data and auditable automations.</li>
                </ul>
                <div className="mt-6 rounded-xl border border-slate-200 p-4 text-xs text-slate-500">
                  <div className="font-medium text-slate-700">Address</div>
                  <div>InsightsIQ, Princeton, NJ • United States</div>
                  <div className="mt-2">Contact: hello@insightsIQ.us</div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer id="company" className="py-12">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8 text-sm">
              <div>
                <div className="flex items-center gap-2 font-semibold"><span className="inline-flex h-8 w-8 items-center justify-center rounded-xl bg-slate-900 text-white">IQ</span> InsightsIQ</div>
                <p className="mt-3 text-slate-600">Boosting EV‑charging availability with AI‑driven monitoring, prediction, and automation.</p>
              </div>
              <div>
                <div className="font-semibold">Solutions</div>
                <ul className="mt-2 space-y-2 text-slate-600">
                  <li><a href="#solutions" className="hover:text-slate-900">For CPOs</a></li>
                  <li><a href="#solutions" className="hover:text-slate-900">For CPMS</a></li>
                  <li><a href="#solutions" className="hover:text-slate-900">For Hardware</a></li>
                </ul>
              </div>
              <div>
                <div className="font-semibold">Products</div>
                <ul className="mt-2 space-y-2 text-slate-600">
                  <li><a href="#products" className="hover:text-slate-900">Monitor</a></li>
                  <li><a href="#products" className="hover:text-slate-900">Predict</a></li>
                  <li><a href="#products" className="hover:text-slate-900">Automate</a></li>
                  <li><a href="#products" className="hover:text-slate-900">Bridge API</a></li>
                </ul>
              </div>
              <div>
                <div className="font-semibold">Legal</div>
                <ul className="mt-2 space-y-2 text-slate-600">
                  <li><a href="#" className="hover:text-slate-900">Privacy</a></li>
                  <li><a href="#" className="hover:text-slate-900">Terms</a></li>
                </ul>
              </div>
            </div>
            <div className="mt-8 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-500">
              <div>© {new Date().getFullYear()} InsightsIQ. All rights reserved.</div>
              <div className="flex items-center gap-3">
                <a className="hover:text-slate-800" href="#">LinkedIn</a>
                <a className="hover:text-slate-800" href="#">GitHub</a>
                <a className="hover:text-slate-800" href="#contact">Contact</a>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </MotionConfig>
  );
}
